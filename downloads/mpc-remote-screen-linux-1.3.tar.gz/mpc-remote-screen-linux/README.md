# MPC Remote Screen

Eigenständiger Viewer für Android und Linux. Er zeigt den Bildschirm einer MPC an und sendet auf Wunsch Tippen, Klicken und Ziehen. Dafür muss die MPC die Fernsteuerung erlauben. Audio lässt sich separat einschalten, wenn die MPC es freigibt.

## Verbinden

1. Auf der MPC **Preferences → Enhancements → Remote Screen** öffnen und die Funktion aktivieren. Für die Bedienung **Allow Remote Control** und für Ton **Share Audio** aktivieren.
2. Viewer und MPC über dasselbe lokale Netz verbinden. Im Viewer die auf der MPC angezeigte IP-Adresse und das Remote-Screen-Passwort eingeben. Der Standardport ist TCP 7447. Alternativ beispielsweise `192.168.1.80:7447` oder `[fd00::123]:7447` eingeben.
3. **Verbinden** wählen. Mit **Steuerung** wird die Bildfläche interaktiv. Mit **Audio** lässt sich die Übertragung der MPC-Hauptausgänge einschalten.

Der Protokoll-Handshake authentifiziert per Passwort. Die Übertragung läuft im Klartext und ist für ein vertrauenswürdiges lokales Netz gedacht.

## Installation

- **Android ab 8.0 (API 26)**. Die APK auf dem Gerät öffnen und dem verwendeten Dateimanager oder Browser bei Bedarf die Installation erlauben.
- **Vollbild auf Android**. Oben rechts auf **Vollbild** tippen. An derselben Stelle führt **Fenster** zur normalen Ansicht zurück.
- **RPM unter Linux**. Auf Fedora und kompatiblen Systemen im Ordner mit der RPM-Datei `sudo dnf install ./mpc-remote-screen-1.3-1.noarch.rpm` ausführen. Danach **MPC Remote Screen** im App-Menü öffnen oder `mpc-remote-screen` im Terminal eingeben.
- **Vollbild unter Linux**. Mit **Vollbild** oder **F11** wechseln. Mit **Fenster**, **F11** oder **Esc** zurückkehren.
- **Linux-Startdiagnose**. `mpc-remote-screen --diagnose` prüft die Java-Laufzeit und den Zugriff auf die grafische Anzeige. Bei einem Start über das App-Menü stehen Meldungen unter `${XDG_STATE_HOME:-$HOME/.local/state}/mpc-remote-screen/startup.log`.
- **Linux**. Das Archiv entpacken, den Ordner öffnen und im Terminal `./mpc-remote-screen` ausführen. Voraussetzung ist eine Java-Laufzeit mit grafischer Desktop-Unterstützung, zum Beispiel OpenJDK 17. Die JAR lässt sich auch mit `java -jar mpc-remote-screen-linux.jar` starten. Der gleiche Build ist unter anderem für x86_64 und ARM64 verwendbar.

## Funktionsumfang

Der Viewer unterstützt Netzwerkverbindungen mit Remote Screen v2, Bildschirmrotation, einfache Touch- und Mausgesten und PCM16-Audio in Mono oder Stereo. Er handelt Raw, LZ4, Vollton und JPEG für die Bildschirmdaten aus. Die Geräteverbindung wurde mit einem lokalen Protokollsimulator geprüft. Physische MPC-Hardware stand für den Test nicht zur Verfügung.

## Bauen

Setze `JAVA_HOME` auf ein JDK wie OpenJDK 21 und starte `./build.sh linux`. Für Android verwende `./build.sh android` und setze zusätzlich:

- `ANDROID_PLATFORM` auf die Android-SDK-Plattform 34 mit `android.jar`.
- `ANDROID_BUILD_TOOLS` auf das SDK-Verzeichnis für Build Tools 36.0.0.
- `APK_KEYSTORE` und `APK_KEY_ALIAS` auf den eigenen Signaturschlüssel. Das Skript fragt nach dem Passwort. Für automatisierte lokale Builds unterstützt `apksigner` Eingabe über Standardinput.

Die Ergebnisse liegen in `dist/`. Für Updates über eine vorhandene Installation muss derselbe Signaturschlüssel verwendet werden.

Mit installiertem `rpmbuild` erzeugt `./build.sh rpm` zusätzlich das RPM-Paket.

## Quellen

[Ko-fi Creator Kit](https://more.ko-fi.com/brand-assets)  
[Barlow, SIL Open Font License](https://github.com/google/fonts/tree/main/ofl/barlow)  
[FlatLaf, Apache 2.0](https://www.formdev.com/flatlaf/)  

[MPC-Remote-Screen-FAQ von inMusic](https://support.inmusicstore.com/en/support/solutions/articles/69000885284-mpc-3-10-1-enhancements-frequently-asked-questions)  
[Offizielles Release 1.5](https://github.com/inmusic-software/mpc-remote-screen/releases/tag/release/v1.5)  
[Community-Beschreibung des Protokolls v2](https://github.com/simonas-notcat/mpc-remote-screen-viewer-gpui/blob/44ef1480870fc45316528546cb86d55b1195add5/SPEC.md)
